#ifndef _HELL_UTIL_HEADER_
#define _HELL_UTIL_HEADER_

#include <string>


class HUtil {
public:
	HUtil(LPCWSTR module);
	~HUtil();

	DWORD Offset(DWORD offset);

	void OpenConsole(const char* name);
	void CloseConsole();

private:
	DWORD mBase = NULL;
	FILE* mConsoleOut;
	std::streambuf* mConsoleOutBackup;
	BOOL mConsoleOpen = FALSE;

};


#endif // !_HELL_UTIL_HEADER_